
package bilibili.daichang.lolipickaxe.item.addon;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LoliRedstonAddon2Item extends Item {
	public LoliRedstonAddon2Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
