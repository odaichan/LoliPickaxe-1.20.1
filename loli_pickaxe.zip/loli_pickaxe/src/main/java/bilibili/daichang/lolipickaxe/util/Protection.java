package bilibili.daichang.lolipickaxe.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class Protection {
    public static void protectionEntity(Entity entity){
        entity.canUpdate(false);
        if(entity instanceof LivingEntity livingEntity){
            livingEntity.setHealth(0.0F);
            livingEntity.canUpdate(false);
            livingEntity.setNoGravity(true);
            livingEntity.noPhysics = true;
            livingEntity.deathTime = Integer.MAX_VALUE;
            livingEntity.hurtMarked = true;
            livingEntity.setInvisible(true);
            livingEntity.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0F);
            livingEntity.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0F);
            HealthHelper.Override_DATA_HEALTH_ID(livingEntity, 0.0F);
            livingEntity.isDeadOrDying();
        }
    }
}
