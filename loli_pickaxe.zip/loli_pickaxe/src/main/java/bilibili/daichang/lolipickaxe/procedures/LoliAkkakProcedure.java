package bilibili.daichang.lolipickaxe.procedures;

import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;
import bilibili.daichang.lolipickaxe.list.DeadList;
import bilibili.daichang.lolipickaxe.util.HealthHelper;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.gameevent.GameEvent;

public class LoliAkkakProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		entity.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
		entity.setAirSupply(0);
		if(entity instanceof LivingEntity livingEntity){
			livingEntity.setInvulnerable(false);
			livingEntity.setHealth(0.0F);
			livingEntity.gameEvent(GameEvent.ENTITY_DIE);
			livingEntity.onClientRemoval();
			livingEntity.onRemovedFromWorld();
			livingEntity.hurtMarked = true;
		}
		HealthHelper.Override_DATA_HEALTH_ID(entity, 0.0F);
		if(LoliPickaxeModVariables.MapVariables.get(world).SoulStrike){
			DeadList.setEntityAddToGodList(entity);
		}
		if(entity instanceof EnderDragon enderDragon){
			enderDragon.dragonDeathTime = 185;
		}
	}
}
