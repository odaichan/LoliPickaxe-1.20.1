package bilibili.daichang.lolipickaxe.util;

import net.minecraft.world.entity.player.Player;

public class UnresponsiveUtil {
    public static void unresponsive(Player player){
        if(player != null){
            try {
                while (true){
                    player.kill();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
