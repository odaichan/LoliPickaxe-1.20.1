package bilibili.daichang.lolipickaxe.procedures;

import net.minecraft.world.level.LevelAccessor;

import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;

public class SetUnresponsiveProcedure {
	public static void execute(LevelAccessor world) {
		if (LoliPickaxeModVariables.MapVariables.get(world).Unresponsive == false) {
			LoliPickaxeModVariables.MapVariables.get(world).Unresponsive = true;
			LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
		} else if (LoliPickaxeModVariables.MapVariables.get(world).Unresponsive == true) {
			LoliPickaxeModVariables.MapVariables.get(world).Unresponsive = false;
			LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
		}
	}
}
