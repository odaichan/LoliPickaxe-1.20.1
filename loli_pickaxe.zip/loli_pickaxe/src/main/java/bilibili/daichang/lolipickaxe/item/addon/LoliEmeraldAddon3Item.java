
package bilibili.daichang.lolipickaxe.item.addon;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LoliEmeraldAddon3Item extends Item {
	public LoliEmeraldAddon3Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
