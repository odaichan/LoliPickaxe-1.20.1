package bilibili.daichang.lolipickaxe.mixins;

import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;
import bilibili.daichang.lolipickaxe.list.DeadList;
import bilibili.daichang.lolipickaxe.list.GodList;
import bilibili.daichang.lolipickaxe.util.PlayerTickUtil;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;


@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Shadow public abstract boolean isAlive();

    @Shadow public abstract boolean equipmentHasChanged(ItemStack p_252265_, ItemStack p_251043_);

    @Shadow protected abstract void tickDeath();

    @Shadow public abstract void tick();

    @Shadow public abstract void forceAddEffect(MobEffectInstance p_147216_, @Nullable Entity p_147217_);

    @Shadow public abstract void push(Entity p_21294_);

    @Shadow public int deathTime;
    @Shadow public int removeArrowTime;

    @Shadow public abstract boolean removeAllEffects();

    @Shadow public int removeStingerTime;
    @Shadow public int hurtTime;
    @Shadow public int hurtDuration;

    @Shadow public abstract void setHealth(float p_21154_);

    @Shadow public abstract void baseTick();

    @Shadow protected boolean dead;

    @Shadow public abstract void heal(float p_21116_);

    @Shadow public abstract float getHealth();

    @Shadow public abstract void clearSleepingPos();
    @Mutable
    @Shadow @Final public static int DEATH_DURATION;
    @Mutable
    @Shadow @Final private static int DAMAGE_SOURCE_TIMEOUT;
    @Unique
    private final LivingEntity loli_pickaxe$entity = (LivingEntity) (Object)this;

    @Inject(method = "getHealth",at=@At("RETURN"), cancellable = true)
    public void getHealth(CallbackInfoReturnable<Float> cir) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                cir.setReturnValue(20.0F);
            }
            if(DeadList.hasPlayer(loli_pickaxe$entity)){
                cir.setReturnValue(0.0F);
            }
        }
        if(loli_pickaxe$entity instanceof LivingEntity){
            if (GodList.hasPlayer(loli_pickaxe$entity)) {
                cir.setReturnValue(0.0f);
            }
        }
    }

    @Inject(method = "isAlive",at=@At("RETURN"), cancellable = true)
    public void isAlive(CallbackInfoReturnable<Boolean> cir) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                cir.setReturnValue(true);
            }
            if(DeadList.hasPlayer(loli_pickaxe$entity)){
                cir.setReturnValue(false);
            }
        }
        if(loli_pickaxe$entity instanceof LivingEntity){
            if (GodList.hasPlayer(loli_pickaxe$entity)) {
                cir.setReturnValue(false);
            }
        }
    }

    @Inject(method = "die",at=@At("RETURN"), cancellable = true)
    public void die(DamageSource p_21014_, CallbackInfo ci) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "kill",at=@At("RETURN"), cancellable = true)
    public void kill(CallbackInfo ci) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "isDeadOrDying",at=@At("RETURN"), cancellable = true)
    public void isDeadOrDying(CallbackInfoReturnable<Boolean> cir) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                cir.setReturnValue(false);
            }
        }
    }

    @Inject(method = "tick",at=@At("RETURN"))
    public void tick(CallbackInfo ci) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                setHealth(20.0F);
                isAlive();
                dead = false;
                deathTime = -2;
                hurtDuration = -2;
                hurtTime = -2;
                heal(20.0f);
                removeAllEffects();
                PlayerTickUtil.execute((Player) loli_pickaxe$entity);
            }
        }
    }

    @Inject(method = "baseTick",at=@At("RETURN"))
    public void baseTick(CallbackInfo ci) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                setHealth(20.0F);
                isAlive();
                dead = false;
                deathTime = -2;
                hurtDuration = -2;
                hurtTime = -2;
                heal(20.0f);
                removeAllEffects();
                PlayerTickUtil.execute((Player) loli_pickaxe$entity);
                clearSleepingPos();
                removeArrowTime = -2;
                removeStingerTime = -2;
            }
        }
        if(loli_pickaxe$entity instanceof LivingEntity){
            if (GodList.hasPlayer(loli_pickaxe$entity)) {
                setHealth(0);
                dead = true;
                heal(0.0f);
            }
        }
    }

    @Inject(method = "tickDeath",at=@At("RETURN"), cancellable = true)
    public void tickDeath(CallbackInfo ci) {
        if (loli_pickaxe$entity instanceof Player) {
            if (((Player) loli_pickaxe$entity).getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
                ci.cancel();
            }
        }
    }
}
