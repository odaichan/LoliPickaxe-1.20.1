
package bilibili.daichang.lolipickaxe.item.tools;

import bilibili.daichang.lolipickaxe.C;
import bilibili.daichang.lolipickaxe.command.ProgramCrashCommond;
import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;
import bilibili.daichang.lolipickaxe.list.GodList;
import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;
import bilibili.daichang.lolipickaxe.procedures.LoliAkkakProcedure;
import bilibili.daichang.lolipickaxe.procedures.LoliAttkeProcedure;
import bilibili.daichang.lolipickaxe.procedures.PlayOggProcedure;
import bilibili.daichang.lolipickaxe.procedures.UnresponsiveProcedure;
import bilibili.daichang.lolipickaxe.util.HealthHelper;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;

public class LoliPickaxeItem extends Item {
	public static boolean kill = false;

	String loli_pickaxe = "此氪金萝莉是带长复刻的，只在像素工坊，CurseForge和我的频道发布，如果您是从其它渠道获取的，说明我的模组被盗了";

	@SubscribeEvent
	public void onRender(ItemTooltipEvent tooltipEvent){
		if(tooltipEvent.getItemStack().getItem() == LoliPickaxeModItems.LOLI_PICKAXE.get()){
			List<Component> tooltip = tooltipEvent.getToolTip();
			int size = tooltip.size();
			Component attackDamage = Component.translatable("attribute.name.generic.attack_damage");
			Component attackSpeed = Component.translatable("attribute.name.generic.attack_speed");
			String var10000 = C.GetColor("TREE(3) ");
			Component replacementAttackDamage = Component.literal(" " + var10000 + ChatFormatting.GRAY + "攻击伤害");
			Component replacementAttackSpeed = Component.literal(" " + var10000 + ChatFormatting.GRAY + "攻击速度");
			for(int i = 0; i < size; ++i) {
				Component line = tooltip.get(i);
				if (line.contains(attackDamage)){
					tooltip.set(i, replacementAttackDamage);
				}
				if (line.contains(attackSpeed)){
					tooltip.set(i, replacementAttackSpeed);
				}
			}
		}
	}

	public LoliPickaxeItem() {
		super(new Properties().stacksTo(1).fireResistant().rarity(Rarity.create("氪金萝莉", ChatFormatting.LIGHT_PURPLE)).setNoRepair().craftRemainder(Items.COMMAND_BLOCK));
		MinecraftForge.EVENT_BUS.register(this);
	}

	@Override
	public float getDestroySpeed(@NotNull ItemStack par1ItemStack, @NotNull BlockState par2Block) {
		return Float.MAX_VALUE;
	}

	@Override
	public @NotNull Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(@NotNull EquipmentSlot equipmentSlot) {
		if (equipmentSlot == EquipmentSlot.MAINHAND) {
			ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
			builder.putAll(super.getDefaultAttributeModifiers(equipmentSlot));
			builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Item modifier", 1d, AttributeModifier.Operation.ADDITION));
			builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Item modifier", -2.4, AttributeModifier.Operation.ADDITION));
			return builder.build();
		}
		return super.getDefaultAttributeModifiers(equipmentSlot);
	}

	@Override
	public @NotNull InteractionResultHolder<ItemStack> use(@NotNull Level world, @NotNull Player entity, @NotNull InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		LoliAttkeProcedure.execute(world, x, y, z, entity);
		return ar;
	}

	@Override
	public boolean hurtEnemy(@NotNull ItemStack itemstack, @NotNull LivingEntity entity, @NotNull LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		itemstack.hurtAndBreak(1, entity, i -> i.broadcastBreakEvent(EquipmentSlot.MAINHAND));
		entity.hurt(new DamageSource(entity.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), sourceentity), Float.POSITIVE_INFINITY);
		LoliAkkakProcedure.execute(entity.level(), entity);
		UnresponsiveProcedure.execute(entity.level(), entity);
		return retval;
	}

	@Override
	public boolean mineBlock(ItemStack itemstack, @NotNull Level world, @NotNull BlockState blockstate, @NotNull BlockPos pos, @NotNull LivingEntity entity) {
		itemstack.hurtAndBreak(0, entity, i -> i.broadcastBreakEvent(EquipmentSlot.MAINHAND));
		return super.mineBlock(itemstack, world, blockstate, pos, entity);
	}

	@Override
	public boolean onEntitySwing(ItemStack itemstack, LivingEntity entity) {
		boolean retval = super.onEntitySwing(itemstack, entity);
		PlayOggProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
		return retval;
	}

	@Override
	public void appendHoverText(@NotNull ItemStack itemstack, Level world, @NotNull List<Component> list, @NotNull TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		if (LoliPickaxeModVariables.MapVariables.get(world).a1) {
			list.add(Component.literal(ChatFormatting.GRAY + "范围挖掘1×1"));
		} else if (LoliPickaxeModVariables.MapVariables.get(world).a3) {
			list.add(Component.literal(ChatFormatting.GRAY + "范围挖掘3*3"));
		} else if (LoliPickaxeModVariables.MapVariables.get(world).a5) {
			list.add(Component.literal(ChatFormatting.GRAY + "范围挖掘5×5"));
		} else if (LoliPickaxeModVariables.MapVariables.get(world).a7) {
			list.add(Component.literal(ChatFormatting.GRAY + "范围挖掘7×7"));
		} else if (LoliPickaxeModVariables.MapVariables.get(world).a9) {
			list.add(Component.literal(ChatFormatting.GRAY + "范围挖掘9×9"));
		} else if (LoliPickaxeModVariables.MapVariables.get(world).a11) {
			list.add(Component.literal(ChatFormatting.GRAY + "范围挖掘11×11"));
		}
		list.add(Component.literal(ChatFormatting.GRAY + "强制移除实体(未制作)"));
		if (LoliPickaxeModVariables.MapVariables.get(world).LeftClickRangeAttack){
			list.add(Component.literal(ChatFormatting.GRAY + "左键范围攻击"));
		}
		if (LoliPickaxeModVariables.MapVariables.get(world).kickPlayer){
			list.add(Component.literal(ChatFormatting.GRAY + "踢除玩家"));
		}
		if (LoliPickaxeModVariables.MapVariables.get(world).SoulStrike){
			list.add(Component.literal(ChatFormatting.GRAY + "灵魂打击"));
		}
		list.add(Component.literal(ChatFormatting.GRAY + "伊邪那美(未实现)"));
		list.add(Component.literal(ChatFormatting.GRAY + "超级时运(目前有严重bug)"));
		list.add(Component.literal(ChatFormatting.GRAY + "自动收纳(未实现)"));
		list.add(Component.literal(ChatFormatting.GRAY + "显示流体边框(未实现)"));
		if(ProgramCrashCommond.program){
			list.add(Component.literal(ChatFormatting.GRAY + "崩溃打击"));
		}
		if (LoliPickaxeModVariables.MapVariables.get(world).Unresponsive){
			list.add(Component.literal(ChatFormatting.GRAY + "未响应打击"));
		}
		if(kill) {
			list.add(Component.literal(ChatFormatting.GRAY + "蓝屏打击"));
		}
		list.add(Component.literal(ChatFormatting.GRAY + "潜行右键范围攻击"));
		list.add(Component.literal(ChatFormatting.GRAY + "反伤"));
	}

	@Override
	public void inventoryTick(@NotNull ItemStack itemstack, @NotNull Level world, @NotNull Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		MinecraftForge.EVENT_BUS.register(this);
		entity.clearFire();
		entity.setTicksFrozen(0);
		if(entity instanceof Player player){
			player.getFoodData().setFoodLevel(20);
			player.getFoodData().setSaturation(20.0f);
			player.getFoodData().setExhaustion(0);
			player.setHealth(20.0F);
			player.isAlive();
			player.clearFire();
			player.removeArrowTime = -2;
			player.removeStingerTime = -2;
			player.deathTime = -2;
			player.hurtTime = -2;
			player.removeAllEffects();
			player.hurtDuration = -2;
			player.canUpdate(true);
			player.setAirSupply(300);
			player.bob = 0;
			player.getAbilities().mayfly = true;
			player.fallDistance = 0;
		}
		Objects.requireNonNull(((LivingEntity) entity).getAttribute(Attributes.MAX_HEALTH)).setBaseValue(20);
	}

	@Override
	public boolean onLeftClickEntity(ItemStack stack, Player player, Entity entity) {
		if(!(entity.isMultipartEntity())) {
			if (entity instanceof WitherBoss witherBoss) {
				witherBoss.hurt(new DamageSource(witherBoss.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player), Float.POSITIVE_INFINITY);
				entity.awardKillScore(witherBoss, 1, new DamageSource(witherBoss.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player));
				witherBoss.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0f);
				witherBoss.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
				witherBoss.hurtMarked = true;
				witherBoss.captureDrops();
				witherBoss.onRemovedFromWorld();
				witherBoss.onClientRemoval();
				witherBoss.gameEvent(GameEvent.ENTITY_DIE);
				witherBoss.setNoAi(true);
				witherBoss.getAttributes().getDirtyAttributes().clear();
				HealthHelper.Override_DATA_HEALTH_ID(witherBoss, 0.0F);
				GodList.addPlayer(entity);
			}
			if (entity instanceof LivingEntity living) {
				if (!(living instanceof Player)) {
					if (!(living instanceof EnderDragon)) {
						living.hurt(new DamageSource(living.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player), Float.POSITIVE_INFINITY);
						living.setHealth(0);
						entity.awardKillScore(living, 1, new DamageSource(living.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player));
					}
				}
			}
			if (entity instanceof Player dead) {
				if (!(dead.getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get())))) {
					HealthHelper.Override_DATA_HEALTH_ID(dead, 0.0f);
					dead.hurt(new DamageSource(dead.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player), Float.POSITIVE_INFINITY);
					dead.die(new DamageSource(dead.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player));
					dead.getInventory().dropAll();
					dead.isDeadOrDying();
					dead.setHealth(0);
					dead.getAbilities().invulnerable = false;
					dead.hurtTime = (int) Float.POSITIVE_INFINITY;
					dead.foodData.setFoodLevel(0);
					dead.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0f);
					dead.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
					dead.gameEvent(GameEvent.ENTITY_DIE);
					dead.gameEvent(GameEvent.ENTITY_DAMAGE);
					dead.gameEvent(GameEvent.ENTITY_DISMOUNT);
					dead.removeAllEffects();
					byte death = EntityEvent.DEATH;
					byte stop_attacking = EntityEvent.START_ATTACKING;
					dead.handleEntityEvent(death);
					dead.handleEntityEvent(stop_attacking);
					dead.getAbilities().invulnerable = false;
					dead.getAbilities().flying = false;
					Level world = entity.level();
					if (LoliPickaxeModVariables.MapVariables.get(world).Unresponsive) {
						dead.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(LoliPickaxeModItems.UNRESPONSIVE.get()));
					}
					if (ProgramCrashCommond.program) {
						dead.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(LoliPickaxeModItems.PROGRAM_CRASH.get()));
					}
					if (kill) {
						dead.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(LoliPickaxeModItems.KILL_WIDOWS.get()));
					}
				}
			}
		}
		return super.onLeftClickEntity(stack, player, entity);
	}

	@Override
	public boolean canPerformAction(ItemStack stack, ToolAction toolAction) {
		return ToolActions.DEFAULT_AXE_ACTIONS.contains(toolAction) || ToolActions.DEFAULT_HOE_ACTIONS.contains(toolAction) || ToolActions.DEFAULT_SHOVEL_ACTIONS.contains(toolAction) || ToolActions.DEFAULT_PICKAXE_ACTIONS.contains(toolAction)
				|| ToolActions.DEFAULT_SWORD_ACTIONS.contains(toolAction);
	}

	@Override
	public boolean canBeDepleted() {
		return false;
	}

	@Override
	public boolean canDisableShield(ItemStack stack, ItemStack shield, LivingEntity entity, LivingEntity attacker) {
		return true;
	}

	@Override
	public boolean canAttackBlock(@NotNull BlockState blockState, @NotNull Level level, @NotNull BlockPos pos, @NotNull Player player) {
		return super.canAttackBlock(blockState, level, pos, player);
	}

	@Override
	public boolean isCorrectToolForDrops(@NotNull BlockState blockstate) {
		return true;
    }

	@Override
	public boolean isDamaged(ItemStack stack) {
		return false;
	}

	@Override
	public boolean isBarVisible(@NotNull ItemStack itemStack) {
		return false;
	}

	@Override
	public ItemStack getCraftingRemainingItem(ItemStack itemStack) {
		itemStack.getItem();
		return super.getCraftingRemainingItem(itemStack);
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public boolean isFoil(@NotNull ItemStack itemstack) {
		return true;
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack stack, BlockState state) {
		return false;
	}

	@Override
	public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, Player player) {
		itemstack.hurtAndBreak(0, player, i -> i.broadcastBreakEvent(EquipmentSlot.MAINHAND));
		return super.onBlockStartBreak(itemstack, pos, player);
	}
}
