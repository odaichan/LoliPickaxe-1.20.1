package bilibili.daichang.lolipickaxe.command;

import bilibili.daichang.lolipickaxe.util.HealthHelper;
import bilibili.daichang.lolipickaxe.util.Protection;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber
public class LoliPickaxeKillEntity {
    @SubscribeEvent
    public static void registerCommand(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("loli-pickaxe-Kill").requires(s -> s.hasPermission(4)).then(Commands.argument("targets", EntityArgument.entities()).executes(arguments -> {
            List<? extends Entity> entities = EntityArgument.getEntities(arguments, "targets").stream().toList();
            if (!entities.isEmpty()) {
                for (Entity entity : entities) {
                    if (entity instanceof Player player) {
                        player.setInvulnerable(false);
                        player.canUpdate(false);
                        player.setHealth(0);
                        HealthHelper.Override_DATA_HEALTH_ID(player, 0.0f);
                        player.isDeadOrDying();
                        player.kill();
                        player.deathTime = Integer.MAX_VALUE;
                        player.hurtTime = Integer.MAX_VALUE;
                        player.hurtMarked = true;
                        player.kill();
                        player.die(new DamageSource(player.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player));
                        player.getFoodData().setFoodLevel(0);
                        player.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0f);
                        player.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
                        player.gameEvent(GameEvent.ENTITY_DIE);
                        Protection.protectionEntity(player);
                    }
                    if(!(entity instanceof Player)) {
                        entity.onRemovedFromWorld();
                        HealthHelper.Override_DATA_HEALTH_ID(entity, 0.0f);
                        entity.kill();
                        entity.onClientRemoval();
                        if(entity instanceof LivingEntity livingEntity){
                            livingEntity.setInvulnerable(false);
                            livingEntity.gameEvent(GameEvent.ENTITY_DIE);
                            livingEntity.lavaHurt();
                            livingEntity.isDeadOrDying();
                            livingEntity.setHealth(0);
                            livingEntity.gameEvent(GameEvent.ENTITY_DAMAGE);
                            livingEntity.gameEvent(GameEvent.ENTITY_DISMOUNT);
                            livingEntity.hurtMarked = true;
                        }
                    }
                }
                return 1;
            }
            return 2;
        })).executes(arguments -> {
            Entity entity = arguments.getSource().getEntityOrException();
            if (entity instanceof Player player) {
                player.setInvulnerable(false);
                player.canUpdate(false);
                player.setHealth(0);
                HealthHelper.Override_DATA_HEALTH_ID(player, 0.0f);
                player.isDeadOrDying();
                player.kill();
                player.deathTime = Integer.MAX_VALUE;
                player.hurtTime = Integer.MAX_VALUE;
                player.hurtMarked = true;
                player.kill();
                player.die(new DamageSource(player.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), player));
                player.getFoodData().setFoodLevel(0);
                player.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0f);
                player.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
                player.gameEvent(GameEvent.ENTITY_DIE);
                player.setInvulnerable(false);
                Protection.protectionEntity(player);
            }
            return 2;
        }));


        event.getDispatcher().register(Commands.literal("loli-pickaxe-remove-entity").requires(s -> s.hasPermission(4)).then(Commands.argument("targets", EntityArgument.entities()).executes(arguments -> {
            List<? extends Entity> entities = EntityArgument.getEntities(arguments, "targets").stream().toList();
            if (!entities.isEmpty()) {
                for (Entity entity : entities) {
                    if(!(entity instanceof Player)) {
                        entity.canUpdate(false);
                        entity.remove(Entity.RemovalReason.KILLED);
                        entity.setRemoved(Entity.RemovalReason.KILLED);
                        entity.discard();
                        if(entity instanceof LivingEntity livingEntity){
                            livingEntity.setPos(Double.NaN, Double.NaN, Double.NaN);
                            livingEntity.isDeadOrDying();
                            livingEntity.shouldRender(0, 0, 0);
                            byte death = EntityEvent.DEATH;
                            livingEntity.handleEntityEvent(death);
                            livingEntity.gameEvent(GameEvent.ENTITY_DIE);
                            livingEntity.onClientRemoval();
                            livingEntity.onRemovedFromWorld();
                            livingEntity.discard();
                            livingEntity.level().isClientSide();
                        }
                    }
                }
                return 1;
            }
            return 0;
        })).executes(arguments -> {
            Entity entity = arguments.getSource().getEntityOrException();
            if (entity instanceof Player player) {
                player.displayClientMessage(Component.nullToEmpty("你在想什么！"), false);
            }
            return 0;
        }));
    }
}
