package bilibili.daichang.lolipickaxe.api;

public class Main {
    public static void main(String[] args) {
        BlueScreenAPI.API.BlueScreen(true);
    }
}
