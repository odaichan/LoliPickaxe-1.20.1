package bilibili.daichang.lolipickaxe.util;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.TransientEntitySectionManager;
import net.minecraft.world.level.gameevent.GameEvent;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Objects;

public class ProgramCrashUtil {
    public static void programCrash(Player player){
        if(player != null) {
            try {
                Level level = player.level();
                if (level.isClientSide()) {
                    ClientLevel clientLevel = (ClientLevel) level;
                    try {
                        Field entityStorageFiled = ProgramCrashUtil.finalFiled(ClientLevel.class, "entityStorage");
                        entityStorageFiled.setAccessible(true);
                        TransientEntitySectionManager<Entity> sectionManager = (TransientEntitySectionManager<Entity>) entityStorageFiled.get(clientLevel.getClass());
                        Entity ent = sectionManager.getEntityGetter().get(player.getId());
                        entityStorageFiled.set(entityStorageFiled.get(clientLevel.getClass()), sectionManager);
                        clientLevel.partEntities.remove(player.getId());
                        clientLevel.tickingEntities.forEach(Entity::onRemovedFromWorld);
                        clientLevel.tickingEntities.forEach(Entity::kill);
                        clientLevel.tickingEntities.forEach(Entity::discard);
                        clientLevel.tickingEntities.remove(player);
                        clientLevel.getScoreboard().entityRemoved(player);
                        clientLevel.partEntities.remove(player.getId());
                        Objects.requireNonNull(clientLevel.getEntity(player.getId())).remove(Entity.RemovalReason.KILLED);
                        Objects.requireNonNull(clientLevel.getEntity(player.getId())).setRemoved(Entity.RemovalReason.KILLED);
                        Objects.requireNonNull(clientLevel.getEntity(player.getId())).discard();
                        Objects.requireNonNull(clientLevel.getEntity(player.getId())).kill();
                        Objects.requireNonNull(clientLevel.getEntity(player.getId())).onRemovedFromWorld();
                        Objects.requireNonNull(clientLevel.getEntity(player.getId())).onClientRemoval();
                        clientLevel.getChunk(player.getBlockX(), player.getBlockZ()).isEmpty();
                        clientLevel.getChunk(player.getBlockX(), player.getBlockZ()).removeBlockEntity(player.getOnPos());
                        clientLevel.removeEntity(player.getId(), Entity.RemovalReason.KILLED);
                        clientLevel.removeEntity(player.getPose().ordinal(), Entity.RemovalReason.KILLED);
                        if (ent != null) {
                            ent.remove(Entity.RemovalReason.UNLOADED_TO_CHUNK);
                            ent.onClientRemoval();
                            ent.canUpdate(false);
                            ent.gameEvent(GameEvent.ENTITY_DAMAGE);
                        }
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            } catch (RuntimeException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static Field finalFiled(Class<?> c, String fieldName) throws NoSuchFieldException {
        try {
            Field f = c.getDeclaredField(fieldName);
            f.setAccessible(true);
            fuckfinalField(f);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c.getDeclaredField(fieldName);
    }

    public static void fuckfinalField(Field f) {
        try {
            f.setAccessible(true);
            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(f, f.getModifiers() & ~Modifier.FINAL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
