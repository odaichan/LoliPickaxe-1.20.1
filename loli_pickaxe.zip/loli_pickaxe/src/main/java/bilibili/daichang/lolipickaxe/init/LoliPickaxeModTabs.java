
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package bilibili.daichang.lolipickaxe.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import bilibili.daichang.lolipickaxe.LoliPickaxeMod;

public class LoliPickaxeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LoliPickaxeMod.MODID);
	public static final RegistryObject<CreativeModeTab> LOLI_PICKAXE_ITEM_TAB = REGISTRY.register("loli_pickaxe_item_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.loli_pickaxe.loli_pickaxe_item_tab")).icon(() -> new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get())).noScrollBar().displayItems((parameters, tabData) -> {
				tabData.accept(LoliPickaxeModItems.LOLI_PICKAXE.get());
				tabData.accept(LoliPickaxeModItems.ORDINARY_LOLI_PICKAXE.get());
				tabData.accept(LoliPickaxeModItems.SMALL_LOLI_PICKAXE.get());
				tabData.accept(LoliPickaxeModItems.LOLI_DISPERSAL.get());
				tabData.accept(LoliPickaxeModItems.BUG_ENTITY_CLEAR.get());
				tabData.accept(LoliPickaxeModItems.LOLI_CARD.get());
				tabData.accept(LoliPickaxeModItems.LOLI_RECORD.get());
			})

					.build());

	public static final RegistryObject<CreativeModeTab> LOLI_PICKAXE_SYNTHETICS = REGISTRY.register("loli_pickaxe_synthetics",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.loli_pickaxe.loli_pickaxe_synthetics")).icon(() -> new ItemStack(LoliPickaxeModItems.SECOND_LEVEL_BIOLOGICAL_SOUL.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LoliPickaxeModItems.FIRST_LEVEL_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.SECOND_LEVEL_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.THIRD_LEVEL_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.FOURTH_LEVEL_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.FIVE_LEVEL_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.SIXTH_ORDER_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_BIOLOGICAL_SOUL.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_5.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_6.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_7.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_8.get());
				tabData.accept(LoliPickaxeModItems.LOLI_COAL_ADDON_9.get());
				tabData.accept(LoliPickaxeModItems.UTIMATE_LOLI_COAL_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_5.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_6.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_7.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_8.get());
				tabData.accept(LoliPickaxeModItems.LOLI_IRON_ADDON_9.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_IRON_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_5.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_6.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_7.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_8.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GOLD_ADDON_9.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_GOLD_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_REDSTON_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_REDSTON_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_REDSTON_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.UTIMATE_LOLI_REDSTON_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_LAPIN_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_LAPIN_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_LAPIN_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_LAPIN_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.LOLI_LAPIN_ADDON_5.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_LAPIN_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_DIAMOND_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_DIAMOND_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_DIAMOND_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_DIAMOND_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.LOLI_DIAMOND_ADDON_5.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_DIAMOND_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_EMERALD_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_EMERALD_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_EMERALD_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_EMERALD_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.UTLIMATE_LOLI_EMERALD_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_5.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_6.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_7.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_8.get());
				tabData.accept(LoliPickaxeModItems.LOLI_OBSIDIAN_ADDON_9.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_OBSIDIAN_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GLOW_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_GLOW_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_GLOW_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_QUARTZ_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_QUARTZ_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_QUARTZ_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_NETHER_STAR_ADDON_1.get());
				tabData.accept(LoliPickaxeModItems.LOLI_NETHER_STAR_ADDON_2.get());
				tabData.accept(LoliPickaxeModItems.LOLI_NETHER_STAR_ADDON_3.get());
				tabData.accept(LoliPickaxeModItems.LOLI_NETHER_STAR_ADDON_4.get());
				tabData.accept(LoliPickaxeModItems.ULTIMATE_LOLI_NETHER_STAR_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_AUTI_FURNACE_ADDON.get());
				tabData.accept(LoliPickaxeModItems.LOLI_FLY_ADDON.get());
			})

					.build());
}
