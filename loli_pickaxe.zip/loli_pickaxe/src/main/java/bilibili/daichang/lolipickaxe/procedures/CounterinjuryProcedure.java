package bilibili.daichang.lolipickaxe.procedures;

import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;
import bilibili.daichang.lolipickaxe.util.HealthHelper;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class CounterinjuryProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingHurtEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		execute(null, world, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof Player _playerHasItem && _playerHasItem.getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get()))) {
			sourceentity.hurt(new DamageSource(sourceentity.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), entity), Float.POSITIVE_INFINITY);
			HealthHelper.Override_DATA_HEALTH_ID(sourceentity, 0.0f);
			sourceentity.canUpdate(false);
			if(sourceentity instanceof LivingEntity living){
				living.isDeadOrDying();
				living.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
				living.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0f);
				living.setHealth(0);
				living.gameEvent(GameEvent.ENTITY_DIE);
				living.setInvulnerable(false);
				living.hurtMarked = true;
				byte death = EntityEvent.DEATH;
				byte stop_attacking = EntityEvent.START_ATTACKING;
				living.handleEntityEvent(death);
				living.handleEntityEvent(stop_attacking);
			}
		}
	}
}
