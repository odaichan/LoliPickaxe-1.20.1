package bilibili.daichang.lolipickaxe.util;

import net.minecraft.SharedConstants;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityTickList;
import net.minecraft.world.level.entity.TransientEntitySectionManager;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class ClientRemove {
    public static void killEntityer(Entity entity) {
        if(entity instanceof LivingEntity living) {
            living.shouldRender(0,0,0);
            living.setCustomNameVisible(false);
            Level level = living.level();
            if (level.isClientSide()) {
                ClientLevel clientLevel = (ClientLevel) level;
                try {
                    Field entityStorageFiled = ClientRemove.finalFiled(ClientLevel.class, "entityStorage");
                    clientLevel.tickingEntities.remove(living);
                    clientLevel.tickingEntities.forEach(Entity::onRemovedFromWorld);
                    clientLevel.tickingEntities.forEach(Entity::kill);
                    entityStorageFiled.setAccessible(true);
                    TransientEntitySectionManager<Entity> sectionManager = (TransientEntitySectionManager<Entity>) entityStorageFiled.get(clientLevel.getClass());
                    Entity ent = sectionManager.getEntityGetter().get(living.getId());
                    entityStorageFiled.set(entityStorageFiled.get(clientLevel.getClass()), sectionManager);
                    EntityTickList tickList = new EntityTickList();
                    tickList.forEach(Entity::kill);
                    tickList.forEach(Entity::discard);
                    tickList.forEach(Entity::onClientRemoval);
                    tickList.forEach(Entity::onRemovedFromWorld);
                    if (ent != null) {
                        ent.remove(Entity.RemovalReason.UNLOADED_TO_CHUNK);
                        ent.onClientRemoval();
                        ent.kill();
                        ent.removalReason = Entity.RemovalReason.KILLED;
                        ent.onRemovedFromWorld();
                        ent.setRemoved(Entity.RemovalReason.KILLED);
                        ent.discard();
                    }
                } catch (Exception e) {
                    System.out.println("Killed Client Entity：" + entity.getScoreboardName());
                }
            }
        }
    }

    public static <E> Object getField(E instance, Class<? super E> cls, String fieldName, String srg) {
        String[] remap = {srg, fieldName};
        String name = SharedConstants.IS_RUNNING_IN_IDE ? remap[1] : remap[0];
        return ObfuscationReflectionHelper.getPrivateValue(cls, instance, name);
    }

    public static <T, E> void fieldSetField(T instance, Class<? super T> cls, String fieldName, E val, String srg) {
        String[] remap = {srg, fieldName};
        String name = SharedConstants.IS_RUNNING_IN_IDE ? remap[1] : remap[0];
        try {
            ObfuscationReflectionHelper.setPrivateValue(cls, instance, val, name);
        } catch (Exception exception) {
        }
    }

    public static Field finalFiled(Class<?> c, String fieldName) throws NoSuchFieldException {
        try {
            Field f = c.getDeclaredField(fieldName);
            f.setAccessible(true);
            fuckfinalField(f);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c.getDeclaredField(fieldName);
    }

    public static void fuckfinalField(Field f) {
        try {
            f.setAccessible(true);
            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(f, f.getModifiers() & ~Modifier.FINAL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
