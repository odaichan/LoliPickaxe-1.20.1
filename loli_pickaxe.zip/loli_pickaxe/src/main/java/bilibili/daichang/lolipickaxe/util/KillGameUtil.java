package bilibili.daichang.lolipickaxe.util;

class KillGameUtil {
    public static native void RtlAdjustPrivilege(long l1, long l2, boolean f, byte b);
    static class NTDLL{
        static {
            System.loadLibrary("ntdll.dll");
        }
    }

    public static void main(String[] args) {
        System.loadLibrary("ntdll.dll");
    }
}
