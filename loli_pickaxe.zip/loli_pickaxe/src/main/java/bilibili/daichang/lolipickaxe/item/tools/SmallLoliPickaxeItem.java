
package bilibili.daichang.lolipickaxe.item.tools;

import bilibili.daichang.lolipickaxe.G;
import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;
import bilibili.daichang.lolipickaxe.procedures.SmallLoliPickaxeAttakProcedure;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SmallLoliPickaxeItem extends TieredItem {
	String loli_pickaxe = "此氪金萝莉是带长复刻的，只在像素工坊和我的频道发布，如果您是从其它渠道获取的，说明我的模组被盗了";

	public SmallLoliPickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 0;
			}

			public float getSpeed() {
				return Float.MAX_VALUE;
			}

			public float getAttackDamageBonus() {
				return (float) Double.MAX_VALUE;
			}

			public int getLevel() {
				return 174;
			}

			public int getEnchantmentValue() {
				return 30;
			}

			public @NotNull Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, new Item.Properties());
		MinecraftForge.EVENT_BUS.register(this);
	}

	@Override
	public boolean isCorrectToolForDrops(@NotNull BlockState blockstate) {
		int tier = 9000;
		blockstate.isAir();
		if (tier < 3 && blockstate.is(BlockTags.NEEDS_DIAMOND_TOOL)) {
			return false;
		} else if (tier < 2 && blockstate.is(BlockTags.NEEDS_IRON_TOOL)) {
			return false;
		} else {
			return tier < 1 && blockstate.is(BlockTags.NEEDS_STONE_TOOL)
					? false
					: (blockstate.is(BlockTags.MINEABLE_WITH_AXE) || blockstate.is(BlockTags.MINEABLE_WITH_HOE) || blockstate.is(BlockTags.MINEABLE_WITH_PICKAXE) || blockstate.is(BlockTags.MINEABLE_WITH_SHOVEL) || blockstate.is(BlockTags.ALL_HANGING_SIGNS) || blockstate.is(BlockTags.SWORD_EFFICIENT));
		}
    }

	@Override
	public boolean canPerformAction(ItemStack stack, ToolAction toolAction) {
		return ToolActions.DEFAULT_AXE_ACTIONS.contains(toolAction) || ToolActions.DEFAULT_HOE_ACTIONS.contains(toolAction) || ToolActions.DEFAULT_SHOVEL_ACTIONS.contains(toolAction) || ToolActions.DEFAULT_PICKAXE_ACTIONS.contains(toolAction)
				|| ToolActions.DEFAULT_SWORD_ACTIONS.contains(toolAction);
	}

	@Override
	public float getDestroySpeed(@NotNull ItemStack itemstack, @NotNull BlockState blockstate) {
		return Float.MAX_VALUE;
	}

	@Override
	public @NotNull Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(@NotNull EquipmentSlot equipmentSlot) {
		if (equipmentSlot == EquipmentSlot.MAINHAND) {
			ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
			builder.putAll(super.getDefaultAttributeModifiers(equipmentSlot));
			builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Tool modifier", (float) Double.MAX_VALUE, AttributeModifier.Operation.ADDITION));
			builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Tool modifier", -3, AttributeModifier.Operation.ADDITION));
			return builder.build();
		}
		return super.getDefaultAttributeModifiers(equipmentSlot);
	}

	@Override
	public boolean mineBlock(ItemStack itemstack, @NotNull Level world, @NotNull BlockState blockstate, @NotNull BlockPos pos, @NotNull LivingEntity entity) {
		itemstack.hurtAndBreak(0, entity, i -> i.broadcastBreakEvent(EquipmentSlot.MAINHAND));
		return true;
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, @NotNull LivingEntity entity, @NotNull LivingEntity sourceEntity) {
		itemstack.hurtAndBreak(1, entity, i -> i.broadcastBreakEvent(EquipmentSlot.MAINHAND));
		entity.isDeadOrDying();
		entity.setHealth(0);
		entity.onClientRemoval();
		entity.onRemovedFromWorld();
		entity.gameEvent(GameEvent.ENTITY_DIE);
		byte death = EntityEvent.DEATH;
		entity.handleEntityEvent(death);
		entity.onClientRemoval();
		entity.onRemovedFromWorld();
		return true;
	}

	@Override
	public @NotNull InteractionResultHolder<ItemStack> use(@NotNull Level world, @NotNull Player entity, @NotNull InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		SmallLoliPickaxeAttakProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ(), entity);
		return ar;
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public boolean isFoil(@NotNull ItemStack itemstack) {
		return true;
	}

	@SubscribeEvent
	public void onRender(ItemTooltipEvent tooltipEvent){
		if(tooltipEvent.getItemStack().getItem() == LoliPickaxeModItems.SMALL_LOLI_PICKAXE.get()){
			List<Component> tooltip = tooltipEvent.getToolTip();
			int size = tooltip.size();
			Component attackDamage = Component.translatable("attribute.name.generic.attack_damage");
			String var10000 = G.GetColor("1.7E08 ");
			Component replacementAttackDamage = Component.literal(" " + var10000 + ChatFormatting.DARK_GREEN + "攻击伤害");
			for(int i = 0; i < size; ++i) {
				Component line = tooltip.get(i);
				if (line.contains(attackDamage)){
					tooltip.set(i, replacementAttackDamage);
				}
			}
		}
	}

	@Override
	public void appendHoverText(@NotNull ItemStack itemstack, Level world, @NotNull List<Component> list, @NotNull TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("右键范围攻击 24×24"));
		list.add(Component.literal("范围挖掘 3×3"));
	}

	public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
		return (!Enchantments.BLOCK_FORTUNE.equals(enchantment) && super.canApplyAtEnchantingTable(stack, enchantment));
	}
}
