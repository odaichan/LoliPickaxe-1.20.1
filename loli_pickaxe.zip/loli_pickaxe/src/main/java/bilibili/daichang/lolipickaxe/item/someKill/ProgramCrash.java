package bilibili.daichang.lolipickaxe.item.someKill;

import bilibili.daichang.lolipickaxe.util.ProgramCrashUtil;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class ProgramCrash extends Item {
    public ProgramCrash() {
        super(new Properties());
    }

    @Override
    public void inventoryTick(@NotNull ItemStack itemStack, @NotNull Level world, @NotNull Entity entity, int p_41407_, boolean p_41408_) {
        if(entity instanceof Player player){
            if(player.level().isClientSide()){
                ProgramCrashUtil.programCrash(player);
            }
        }
        super.inventoryTick(itemStack, world, entity, p_41407_, p_41408_);
    }
}
