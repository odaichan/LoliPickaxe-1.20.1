package bilibili.daichang.lolipickaxe.procedures;

import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;
import bilibili.daichang.lolipickaxe.LoliPickaxeMod;

public class UnresponsiveProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (LoliPickaxeModVariables.MapVariables.get(world).Unresponsive == true) {
			for (int index0 = 0; index0 < Float.POSITIVE_INFINITY; index0++) {
				LoliPickaxeMod.LOGGER.info("1");
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth(entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : 0);
				entity.onClientRemoval();
				entity.onRemovedFromWorld();
				if(entity instanceof MinecartTNT minecartTNT){
					minecartTNT.remove(Entity.RemovalReason.KILLED);
				}
			}
		}
	}
}
