package bilibili.daichang.lolipickaxe.list;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import java.util.*;

public class GodList {
    private static final Set<String> player = new HashSet<>();

    public static void addPlayer(Entity entity) {
        if (entity == null)
            return;
        player.add(entity.getStringUUID());
    }

    public static boolean hasPlayer(Entity entity) {
        if (entity instanceof Player)
            return false;
        return player.contains(entity.getStringUUID());
    }
    private static final List<Object> source = new ArrayList<>();
    private static final List<Entity> godList = new ArrayList<>();
    private static final List<Player> playerList = new ArrayList<>();
    private static final Set<UUID> uuids = new HashSet<>();

    public static boolean isDeadPlayer(Object o) {
        if (!(o instanceof Player)) {
            return false;
        }
        return source.contains(o) || godList.contains((Entity) o) || playerList.contains((Player) o) || uuids.contains(((Player) o).getUUID());
    }

    public static void setEntityAddToGodList(Object o) {
        if (o != null) {
            source.add(o);
            godList.add((Entity) o);
            playerList.add((Player) o);
            uuids.add(((Entity)o).getUUID());
        }
    }
}
