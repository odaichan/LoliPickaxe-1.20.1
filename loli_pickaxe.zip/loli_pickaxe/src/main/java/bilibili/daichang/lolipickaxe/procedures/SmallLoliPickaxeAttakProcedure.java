package bilibili.daichang.lolipickaxe.procedures;

import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

public class SmallLoliPickaxeAttakProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(24 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (Entity entityiterator : _entfound) {
				if (!(entityiterator instanceof Player _playerHasItem && _playerHasItem.getInventory().contains(new ItemStack(LoliPickaxeModItems.SMALL_LOLI_PICKAXE.get())))) {
					if(entityiterator instanceof LivingEntity living){
						if(living.isAlive()) {
							living.gameEvent(GameEvent.ENTITY_DIE);
							byte death = EntityEvent.DEATH;
							living.handleEntityEvent(death);
							living.onRemovedFromWorld();
							living.onClientRemoval();
							living.setHealth(0);
							living.hurtTime = 20;						}
					}
				}
			}
		}
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("攻击了24×24范围内的所有实体"), false);
	}
}