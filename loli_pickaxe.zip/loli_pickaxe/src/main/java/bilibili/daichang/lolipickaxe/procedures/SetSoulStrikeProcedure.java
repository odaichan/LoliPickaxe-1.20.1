package bilibili.daichang.lolipickaxe.procedures;

import net.minecraft.world.level.LevelAccessor;

import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;

public class SetSoulStrikeProcedure {
	public static void execute(LevelAccessor world) {
		if (LoliPickaxeModVariables.MapVariables.get(world).SoulStrike == false) {
			LoliPickaxeModVariables.MapVariables.get(world).SoulStrike = true;
			LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
		} else if (LoliPickaxeModVariables.MapVariables.get(world).SoulStrike == true) {
			LoliPickaxeModVariables.MapVariables.get(world).SoulStrike = false;
			LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
		}
	}
}
