package bilibili.daichang.lolipickaxe.util;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class HealthHelper {
    public static void copyProperties(Class<?> clazz, Object source, Object target) {
        try {
            Field[] fields = clazz.getDeclaredFields();
            AccessibleObject.setAccessible(fields, true);

            for (Field field : fields) {
                if (!Modifier.isStatic(field.getModifiers())) {
                    field.set(target, field.get(source));
                }
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public static void Override_DATA_HEALTH_ID(LivingEntity livingEntity, float X){

        SynchedEntityData data = new SynchedEntityData(livingEntity) {
            @Override
            @SuppressWarnings("unchecked")
            public <T> @NotNull T get(@NotNull EntityDataAccessor<T> p_135371_) {
                return (T) (p_135371_ == LivingEntity.DATA_HEALTH_ID ? X : super.get(p_135371_));
            }
        };
        copyProperties(SynchedEntityData.class, livingEntity.entityData, data);
        livingEntity.entityData = data;
    }

    public static void Override_DATA_HEALTH_ID(Player player, float X){
        SynchedEntityData data = new SynchedEntityData(player) {
            @Override
            @SuppressWarnings("unchecked")
            public <T> @NotNull T get(@NotNull EntityDataAccessor<T> p_135371_) {
                return (T) (p_135371_ == LivingEntity.DATA_HEALTH_ID ? X : super.get(p_135371_));
            }
        };
        copyProperties(SynchedEntityData.class, player.entityData, data);
        player.entityData = data;

    }
    public static void Override_DATA_HEALTH_ID(Entity entity, float X){
        SynchedEntityData data = new SynchedEntityData(entity) {
            @Override
            @SuppressWarnings("unchecked")
            public <T> @NotNull T get(@NotNull EntityDataAccessor<T> p_135371_) {
                return (T) (p_135371_ == LivingEntity.DATA_HEALTH_ID ? X : super.get(p_135371_));
            }
        };
        copyProperties(SynchedEntityData.class, entity.entityData, data);
        entity.entityData = data;
    }
}
