package bilibili.daichang.lolipickaxe.util;

import net.minecraft.world.entity.player.Player;

public class PlayerTickUtil {
    public static float execute(Player player) {
        if (player == null)
            return 20;
        player.setHealth(20);
        player.setAirSupply(300);
        player.hurtTime = -2;
        player.canUpdate(true);
        player.isAlive();
        player.clearFire();
        return player.getHealth();
    }
}
