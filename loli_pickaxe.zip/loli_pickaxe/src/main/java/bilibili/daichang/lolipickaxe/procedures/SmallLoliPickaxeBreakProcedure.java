package bilibili.daichang.lolipickaxe.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.level.BlockEvent;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;

@Mod.EventBusSubscriber
public class SmallLoliPickaxeBreakProcedure {
	@SubscribeEvent
	public static void onBlockBreak(BlockEvent.BreakEvent event) {
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getPlayer());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == LoliPickaxeModItems.SMALL_LOLI_PICKAXE.get()) {
			{
				int _x = (int) ((entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getX() - 1));
				int _y = (int) ((entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getY() - 1));
				int _z = (int) ((entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ() - 1));
				int _dx = 0;
				int _dy = 0;
				int _dz = 0;
				boolean _bdx = (Math.abs((int) (2)) == (int) (2));
				boolean _bdy = (Math.abs((int) (2)) == (int) (2));
				boolean _bdz = (Math.abs((int) (2)) == (int) (2));
				boolean _break = false;
				for (int _fx = 0; _fx <= (Math.abs((int) (2))); _fx++) {
					_dy = 0;
					int _bx = _x + _dx;
					for (int _fy = 0; _fy <= (Math.abs((int) (2))); _fy++) {
						_dz = 0;
						int _by = _y + _dy;
						for (int _fz = 0; _fz <= (Math.abs((int) (2))); _fz++) {
							int _bz = _z + _dz;
							BlockState _fbs = world.getBlockState(new BlockPos(_bx, _by, _bz));
							{
								BlockPos _pos = BlockPos.containing(_bx, _by, _bz);
								Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							_break = false;
							if (_bdz) {
								_dz++;
							} else {
								_dz--;
							}
							if (_break)
								break;
						}
						if (_bdy) {
							_dy++;
						} else {
							_dy--;
						}
						if (_break)
							break;
					}
					if (_bdx) {
						_dx++;
					} else {
						_dx--;
					}
					if (_break)
						break;
				}
			}
		}
	}
}
