
package bilibili.daichang.lolipickaxe.item.addon;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LoliObsidianAddon5Item extends Item {
	public LoliObsidianAddon5Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
