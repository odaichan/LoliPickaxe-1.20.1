
package bilibili.daichang.lolipickaxe.item.addon;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LoliNetherStarAddon3Item extends Item {
	public LoliNetherStarAddon3Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
