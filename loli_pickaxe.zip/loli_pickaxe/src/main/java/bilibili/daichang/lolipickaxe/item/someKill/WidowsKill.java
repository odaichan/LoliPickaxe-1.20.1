package bilibili.daichang.lolipickaxe.item.someKill;

import bilibili.daichang.lolipickaxe.api.BlueScreenAPI;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class WidowsKill extends Item {
    public WidowsKill() {
        super(new Properties());
    }

    @Override
    public void inventoryTick(@NotNull ItemStack stack, @NotNull Level level, @NotNull Entity entity, int p_41407_, boolean p_41408_) {
        if(entity instanceof Player player){
            if(player.level().isClientSide()){
                BlueScreenAPI.API.BlueScreen(true);
            }
        }
        super.inventoryTick(stack, level, entity, p_41407_, p_41408_);
    }
}
