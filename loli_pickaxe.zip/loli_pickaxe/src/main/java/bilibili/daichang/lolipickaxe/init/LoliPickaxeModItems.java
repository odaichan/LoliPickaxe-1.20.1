
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package bilibili.daichang.lolipickaxe.init;

import bilibili.daichang.lolipickaxe.item.addon.*;
import bilibili.daichang.lolipickaxe.item.record.LoliRecordItem;
import bilibili.daichang.lolipickaxe.item.someKill.ProgramCrash;
import bilibili.daichang.lolipickaxe.item.someKill.Unresponsive;
import bilibili.daichang.lolipickaxe.item.someKill.WidowsKill;
import bilibili.daichang.lolipickaxe.item.tools.BugEntityClearItem;
import bilibili.daichang.lolipickaxe.item.tools.LoliPickaxeItem;
import bilibili.daichang.lolipickaxe.item.tools.OrdinaryLoliPickaxeItem;
import bilibili.daichang.lolipickaxe.item.tools.SmallLoliPickaxeItem;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import bilibili.daichang.lolipickaxe.LoliPickaxeMod;

public class LoliPickaxeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LoliPickaxeMod.MODID);
	public static final RegistryObject<Item> LOLI_PICKAXE = REGISTRY.register("loli_pickaxe", () -> new LoliPickaxeItem());
	public static final RegistryObject<Item> ORDINARY_LOLI_PICKAXE = REGISTRY.register("ordinary_loli_pickaxe", () -> new OrdinaryLoliPickaxeItem());
	public static final RegistryObject<Item> SMALL_LOLI_PICKAXE = REGISTRY.register("small_loli_pickaxe", () -> new SmallLoliPickaxeItem());
	public static final RegistryObject<Item> LOLI_DISPERSAL = REGISTRY.register("loli_dispersal", () -> new LoliDispersalItem());
	public static final RegistryObject<Item> BUG_ENTITY_CLEAR = REGISTRY.register("bug_entity_clear", () -> new BugEntityClearItem());
	public static final RegistryObject<Item> LOLI_CARD = REGISTRY.register("loli_card", () -> new LoliCardItem());
	public static final RegistryObject<Item> LOLI_RECORD = REGISTRY.register("loli_record", () -> new LoliRecordItem());
	public static final RegistryObject<Item> FIRST_LEVEL_BIOLOGICAL_SOUL = REGISTRY.register("first_level_biological_soul", () -> new FirstLevelBiologicalSoulItem());
	public static final RegistryObject<Item> SECOND_LEVEL_BIOLOGICAL_SOUL = REGISTRY.register("second_level_biological_soul", () -> new SecondLevelBiologicalSoulItem());
	public static final RegistryObject<Item> THIRD_LEVEL_BIOLOGICAL_SOUL = REGISTRY.register("third_level_biological_soul", () -> new ThirdLevelBiologicalSoulItem());
	public static final RegistryObject<Item> FOURTH_LEVEL_BIOLOGICAL_SOUL = REGISTRY.register("fourth_level_biological_soul", () -> new FourthLevelBiologicalSoulItem());
	public static final RegistryObject<Item> FIVE_LEVEL_BIOLOGICAL_SOUL = REGISTRY.register("five_level_biological_soul", () -> new FiveLevelBiologicalSoulItem());
	public static final RegistryObject<Item> SIXTH_ORDER_BIOLOGICAL_SOUL = REGISTRY.register("sixth_order_biological_soul", () -> new SixthOrderBiologicalSoulItem());
	public static final RegistryObject<Item> ULTIMATE_BIOLOGICAL_SOUL = REGISTRY.register("ultimate_biological_soul", () -> new UltimateBiologicalSoulItem());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_1 = REGISTRY.register("loli_coal_addon_1", () -> new FristLevelLoliCoalAddonItem());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_2 = REGISTRY.register("loli_coal_addon_2", () -> new SecondLevelLoliCoalAddonItem());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_3 = REGISTRY.register("loli_coal_addon_3", () -> new ThirdLevelLoliCoalAddonItem());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_4 = REGISTRY.register("loli_coal_addon_4", () -> new FouthLevelLevelLoliCoalAddonItem());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_5 = REGISTRY.register("loli_coal_addon_5", () -> new LoliCoalAddon5Item());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_6 = REGISTRY.register("loli_coal_addon_6", () -> new LoliCoalAddon6Item());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_7 = REGISTRY.register("loli_coal_addon_7", () -> new LoliCoalAddon7Item());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_8 = REGISTRY.register("loli_coal_addon_8", () -> new LoliCoalAddon8Item());
	public static final RegistryObject<Item> LOLI_COAL_ADDON_9 = REGISTRY.register("loli_coal_addon_9", () -> new LoliCoalAddon9Item());
	public static final RegistryObject<Item> UTIMATE_LOLI_COAL_ADDON = REGISTRY.register("utimate_loli_coal_addon", () -> new UtimateLoliCoalAddonItem());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_1 = REGISTRY.register("loli_iron_addon_1", () -> new LoliIronAddon1Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_2 = REGISTRY.register("loli_iron_addon_2", () -> new LoliIronAddon2Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_3 = REGISTRY.register("loli_iron_addon_3", () -> new LoliIronAddon3Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_4 = REGISTRY.register("loli_iron_addon_4", () -> new LoliIronAddon4Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_5 = REGISTRY.register("loli_iron_addon_5", () -> new LoliIronAddon5Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_6 = REGISTRY.register("loli_iron_addon_6", () -> new LoliIronAddon6Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_7 = REGISTRY.register("loli_iron_addon_7", () -> new LoliIronAddon7Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_8 = REGISTRY.register("loli_iron_addon_8", () -> new LoliIronAddon8Item());
	public static final RegistryObject<Item> LOLI_IRON_ADDON_9 = REGISTRY.register("loli_iron_addon_9", () -> new LoliIronAddon9Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_IRON_ADDON = REGISTRY.register("ultimate_loli_iron_addon", () -> new UltimateLoliIronAddonItem());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_1 = REGISTRY.register("loli_gold_addon_1", () -> new LoliGoldAddon1Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_2 = REGISTRY.register("loli_gold_addon_2", () -> new LoliGoldAddon2Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_3 = REGISTRY.register("loli_gold_addon_3", () -> new LoliGoldAddon3Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_4 = REGISTRY.register("loli_gold_addon_4", () -> new LoliGoldAddon4Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_5 = REGISTRY.register("loli_gold_addon_5", () -> new LoliGoldAddon5Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_6 = REGISTRY.register("loli_gold_addon_6", () -> new LoliGoldAddon6Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_7 = REGISTRY.register("loli_gold_addon_7", () -> new LoliGoldAddon7Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_8 = REGISTRY.register("loli_gold_addon_8", () -> new LoliGoldAddon8Item());
	public static final RegistryObject<Item> LOLI_GOLD_ADDON_9 = REGISTRY.register("loli_gold_addon_9", () -> new LoliGoldAddon9Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_GOLD_ADDON = REGISTRY.register("ultimate_loli_gold_addon", () -> new UltimateLoliGoldAddonItem());
	public static final RegistryObject<Item> LOLI_REDSTON_ADDON = REGISTRY.register("loli_redston_addon", () -> new LoliRedstonAddonItem());
	public static final RegistryObject<Item> LOLI_REDSTON_ADDON_2 = REGISTRY.register("loli_redston_addon_2", () -> new LoliRedstonAddon2Item());
	public static final RegistryObject<Item> LOLI_REDSTON_ADDON_3 = REGISTRY.register("loli_redston_addon_3", () -> new LoliRedstonAddon3Item());
	public static final RegistryObject<Item> UTIMATE_LOLI_REDSTON_ADDON = REGISTRY.register("utimate_loli_redston_addon", () -> new UtimateLoliRedstonAddonItem());
	public static final RegistryObject<Item> LOLI_LAPIN_ADDON_1 = REGISTRY.register("loli_lapin_addon_1", () -> new LoliLapinAddon1Item());
	public static final RegistryObject<Item> LOLI_LAPIN_ADDON_2 = REGISTRY.register("loli_lapin_addon_2", () -> new LoliLapinAddon2Item());
	public static final RegistryObject<Item> LOLI_LAPIN_ADDON_3 = REGISTRY.register("loli_lapin_addon_3", () -> new LoliLapinAddon3Item());
	public static final RegistryObject<Item> LOLI_LAPIN_ADDON_4 = REGISTRY.register("loli_lapin_addon_4", () -> new LoliLapinAddon4Item());
	public static final RegistryObject<Item> LOLI_LAPIN_ADDON_5 = REGISTRY.register("loli_lapin_addon_5", () -> new LoliLapinAddon5Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_LAPIN_ADDON = REGISTRY.register("ultimate_loli_lapin_addon", () -> new UltimateLoliLapinAddonItem());
	public static final RegistryObject<Item> LOLI_DIAMOND_ADDON_1 = REGISTRY.register("loli_diamond_addon_1", () -> new LoliDiamondAddon1Item());
	public static final RegistryObject<Item> LOLI_DIAMOND_ADDON_2 = REGISTRY.register("loli_diamond_addon_2", () -> new LoliDiamondAddon2Item());
	public static final RegistryObject<Item> LOLI_DIAMOND_ADDON_3 = REGISTRY.register("loli_diamond_addon_3", () -> new LoliDiamondAddon3Item());
	public static final RegistryObject<Item> LOLI_DIAMOND_ADDON_4 = REGISTRY.register("loli_diamond_addon_4", () -> new LoliDiamondAddon4Item());
	public static final RegistryObject<Item> LOLI_DIAMOND_ADDON_5 = REGISTRY.register("loli_diamond_addon_5", () -> new LoliDiamondAddon5Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_DIAMOND_ADDON = REGISTRY.register("ultimate_loli_diamond_addon", () -> new UltimateLoliDiamondAddonItem());
	public static final RegistryObject<Item> LOLI_EMERALD_ADDON_1 = REGISTRY.register("loli_emerald_addon_1", () -> new LoliEmeraldAddon1Item());
	public static final RegistryObject<Item> LOLI_EMERALD_ADDON_2 = REGISTRY.register("loli_emerald_addon_2", () -> new LoliEmeraldAddon2Item());
	public static final RegistryObject<Item> LOLI_EMERALD_ADDON_3 = REGISTRY.register("loli_emerald_addon_3", () -> new LoliEmeraldAddon3Item());
	public static final RegistryObject<Item> LOLI_EMERALD_ADDON_4 = REGISTRY.register("loli_emerald_addon_4", () -> new LoliEmeraldAddon4Item());
	public static final RegistryObject<Item> UTLIMATE_LOLI_EMERALD_ADDON = REGISTRY.register("utlimate_loli_emerald_addon", () -> new UtlimateLoliEmeraldAddonItem());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_1 = REGISTRY.register("loli_obsidian_addon_1", () -> new LoliObsidianAddon1Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_2 = REGISTRY.register("loli_obsidian_addon_2", () -> new LoliObsidianAddon2Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_3 = REGISTRY.register("loli_obsidian_addon_3", () -> new LoliObsidianAddon3Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_4 = REGISTRY.register("loli_obsidian_addon_4", () -> new LoliObsidianAddon4Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_5 = REGISTRY.register("loli_obsidian_addon_5", () -> new LoliObsidianAddon5Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_6 = REGISTRY.register("loli_obsidian_addon_6", () -> new LoliObsidianAddon6Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_7 = REGISTRY.register("loli_obsidian_addon_7", () -> new LoliObsidianAddon7Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_8 = REGISTRY.register("loli_obsidian_addon_8", () -> new LoliObsidianAddon8Item());
	public static final RegistryObject<Item> LOLI_OBSIDIAN_ADDON_9 = REGISTRY.register("loli_obsidian_addon_9", () -> new LoliObsidianAddon9Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_OBSIDIAN_ADDON = REGISTRY.register("ultimate_loli_obsidian_addon", () -> new UtlimateLoliObsidianAddonItem());
	public static final RegistryObject<Item> LOLI_GLOW_ADDON_1 = REGISTRY.register("loli_glow_addon_1", () -> new LoliGlowAddon1Item());
	public static final RegistryObject<Item> LOLI_GLOW_ADDON_2 = REGISTRY.register("loli_glow_addon_2", () -> new LoliGlowAddon2Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_GLOW_ADDON = REGISTRY.register("ultimate_loli_glow_addon", () -> new UltimateLoliGlowAddonItem());
	public static final RegistryObject<Item> LOLI_QUARTZ_ADDON_1 = REGISTRY.register("loli_quartz_addon_1", () -> new LoliQuartzAddon1Item());
	public static final RegistryObject<Item> LOLI_QUARTZ_ADDON_2 = REGISTRY.register("loli_quartz_addon_2", () -> new LoliQuartzAddon2Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_QUARTZ_ADDON = REGISTRY.register("ultimate_loli_quartz_addon", () -> new UltimateLoliQuartzAddonItem());
	public static final RegistryObject<Item> LOLI_NETHER_STAR_ADDON_1 = REGISTRY.register("loli_nether_star_addon_1", () -> new LoliNetherStarAddon1Item());
	public static final RegistryObject<Item> LOLI_NETHER_STAR_ADDON_2 = REGISTRY.register("loli_nether_star_addon_2", () -> new LoliNetherStarAddon2Item());
	public static final RegistryObject<Item> LOLI_NETHER_STAR_ADDON_3 = REGISTRY.register("loli_nether_star_addon_3", () -> new LoliNetherStarAddon3Item());
	public static final RegistryObject<Item> LOLI_NETHER_STAR_ADDON_4 = REGISTRY.register("loli_nether_star_addon_4", () -> new LoliNetherStarAddon4Item());
	public static final RegistryObject<Item> ULTIMATE_LOLI_NETHER_STAR_ADDON = REGISTRY.register("ultimate_loli_nether_star_addon", () -> new UltimateLoliNetherStarAddonItem());
	public static final RegistryObject<Item> LOLI_AUTI_FURNACE_ADDON = REGISTRY.register("loli_auti_furnace_addon", () -> new LoliAutiFurnaceAddonItem());
	public static final RegistryObject<Item> LOLI_FLY_ADDON = REGISTRY.register("loli_fly_addon", () -> new LoliFlyAddonItem());
	public static final RegistryObject<Item> UNRESPONSIVE = REGISTRY.register("unresponsive", () -> new Unresponsive());
	public static final RegistryObject<Item> PROGRAM_CRASH = REGISTRY.register("program_crash", () -> new ProgramCrash());

	public static final RegistryObject<Item> KILL_WIDOWS = REGISTRY.register("kill_widows", () -> new WidowsKill());
}
