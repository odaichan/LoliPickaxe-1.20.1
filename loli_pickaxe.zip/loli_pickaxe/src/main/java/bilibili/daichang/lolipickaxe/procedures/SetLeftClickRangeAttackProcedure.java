package bilibili.daichang.lolipickaxe.procedures;

import net.minecraft.world.level.LevelAccessor;

import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;

public class SetLeftClickRangeAttackProcedure {
	public static void execute(LevelAccessor world) {
		if (LoliPickaxeModVariables.MapVariables.get(world).LeftClickRangeAttack == true) {
			LoliPickaxeModVariables.MapVariables.get(world).LeftClickRangeAttack = false;
			LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
		} else if (LoliPickaxeModVariables.MapVariables.get(world).LeftClickRangeAttack == false) {
			LoliPickaxeModVariables.MapVariables.get(world).LeftClickRangeAttack = true;
			LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
		}
	}
}
