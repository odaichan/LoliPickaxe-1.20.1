package bilibili.daichang.lolipickaxe.procedures;

import bilibili.daichang.lolipickaxe.command.ProgramCrashCommond;
import bilibili.daichang.lolipickaxe.init.LoliPickaxeModItems;
import bilibili.daichang.lolipickaxe.item.tools.LoliPickaxeItem;
import bilibili.daichang.lolipickaxe.network.LoliPickaxeModVariables;
import bilibili.daichang.lolipickaxe.util.HealthHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Comparator;
import java.util.List;

public class LoliAttkeProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		int entityCount = 0;
		if (entity == null)
			return;
		if (entity.isShiftKeyDown()) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(200 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (!(entityiterator instanceof Player _playerHasItem && _playerHasItem.getInventory().contains(new ItemStack(LoliPickaxeModItems.LOLI_PICKAXE.get())))) {
						if (!(entityiterator instanceof ItemEntity)) {
							if(entityiterator.isAlive()) {
								if (LoliPickaxeModVariables.MapVariables.get(world).ForcedRemoval) {
									if (entityiterator instanceof LivingEntity _entity)
										_entity.setHealth(0);
									if (!entity.level().isClientSide())
										entity.discard();
									entityiterator.onClientRemoval();
									entityiterator.canUpdate(false);
									entityiterator.onRemovedFromWorld();
								}
								if (entityiterator instanceof LivingEntity livingEntity) {
									entityCount++;
									if (!(livingEntity instanceof WitherBoss)) {
										livingEntity.hurt(new DamageSource(livingEntity.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), entity), Float.POSITIVE_INFINITY);
										livingEntity.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0F);
										livingEntity.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0F);
										livingEntity.setHealth(0);
										livingEntity.isDeadOrDying();
										livingEntity.removeAllEffects();
										livingEntity.onRemovedFromWorld();
										livingEntity.onClientRemoval();
										livingEntity.clearFire();
										if(livingEntity instanceof Player player){
											player.setSprinting(false);
											player.getAbilities().mayBuild = false;
											player.getAbilities().mayfly = false;
											player.getAbilities().invulnerable = false;
											player.getAbilities().instabuild = false;
											player.removeAllEffects();
											player.getFoodData().setFoodLevel(0);
											player.stopUsingItem();
											player.lastLevelUpTime = (int) Float.POSITIVE_INFINITY;
											if(LoliPickaxeModVariables.MapVariables.get(world).Unresponsive){
												player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(LoliPickaxeModItems.UNRESPONSIVE.get()));
											}
											if(ProgramCrashCommond.program){
												player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(LoliPickaxeModItems.PROGRAM_CRASH.get()));
											}
											if(LoliPickaxeItem.kill){
												player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(LoliPickaxeModItems.KILL_WIDOWS.get()));
											}
										}
										if (livingEntity instanceof EnderDragon enderDragon) {
											enderDragon.dragonDeathTime = 190;
											enderDragon.flapTime = 0;
										}
										HealthHelper.Override_DATA_HEALTH_ID(entityiterator, 0.0F);
									}
									if (livingEntity instanceof WitherBoss witherBoss) {
										witherBoss.hurt(new DamageSource(witherBoss.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), entity), Float.POSITIVE_INFINITY);
										witherBoss.awardKillScore(witherBoss, 1, new DamageSource(witherBoss.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FELL_OUT_OF_WORLD), entity));
										witherBoss.setInvulnerable(false);
										witherBoss.entityData.set(LivingEntity.DATA_HEALTH_ID, 0.0f);
										witherBoss.getEntityData().set(LivingEntity.DATA_HEALTH_ID, 0.0f);
										witherBoss.hurtMarked = true;
										witherBoss.setNoAi(true);
										witherBoss.gameEvent(GameEvent.ENTITY_DIE);
										witherBoss.captureDrops();
										witherBoss.onRemovedFromWorld();
										witherBoss.onClientRemoval();
										witherBoss.onAboveBubbleCol(false);
										witherBoss.ambientSoundTime = 0;
									}
								}
							}
						}
					}
				}
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("攻击了100×100范围内的" + entityCount + "个实体"), false);
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("loli_pickaxe:loli_succrss")), SoundSource.NEUTRAL, 1, 1);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("loli_pickaxe:loli_succrss")), SoundSource.NEUTRAL, 1, 1, false);
			}
		}
		if (!entity.isShiftKeyDown()) {
			if (LoliPickaxeModVariables.MapVariables.get(world).a1) {
				LoliPickaxeModVariables.MapVariables.get(world).a1 = false;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				LoliPickaxeModVariables.MapVariables.get(world).a3 = true;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("采掘范围更改为3×3"), false);
			} else if (LoliPickaxeModVariables.MapVariables.get(world).a3) {
				LoliPickaxeModVariables.MapVariables.get(world).a3 = false;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				LoliPickaxeModVariables.MapVariables.get(world).a5 = true;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("采掘范围更改为5×5"), false);
			} else if (LoliPickaxeModVariables.MapVariables.get(world).a5) {
				LoliPickaxeModVariables.MapVariables.get(world).a5 = false;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				LoliPickaxeModVariables.MapVariables.get(world).a7 = true;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("采掘范围更改为7×7"), false);
			} else if (LoliPickaxeModVariables.MapVariables.get(world).a7) {
				LoliPickaxeModVariables.MapVariables.get(world).a7 = false;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				LoliPickaxeModVariables.MapVariables.get(world).a9 = true;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("采掘范围更改为9×9"), false);
			} else if (LoliPickaxeModVariables.MapVariables.get(world).a9) {
				LoliPickaxeModVariables.MapVariables.get(world).a9 = false;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				LoliPickaxeModVariables.MapVariables.get(world).a11 = true;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("采掘范围更改为11×11"), false);
			} else if (LoliPickaxeModVariables.MapVariables.get(world).a11) {
				LoliPickaxeModVariables.MapVariables.get(world).a11 = false;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				LoliPickaxeModVariables.MapVariables.get(world).a1 = true;
				LoliPickaxeModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("采掘范围更改为1×1"), false);
			}
		}
	}
}
