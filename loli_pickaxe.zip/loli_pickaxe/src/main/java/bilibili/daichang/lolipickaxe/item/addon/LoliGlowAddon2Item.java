
package bilibili.daichang.lolipickaxe.item.addon;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LoliGlowAddon2Item extends Item {
	public LoliGlowAddon2Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
