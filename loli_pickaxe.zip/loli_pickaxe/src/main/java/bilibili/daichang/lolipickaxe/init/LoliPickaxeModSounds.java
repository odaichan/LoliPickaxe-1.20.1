
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package bilibili.daichang.lolipickaxe.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import bilibili.daichang.lolipickaxe.LoliPickaxeMod;

public class LoliPickaxeModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, LoliPickaxeMod.MODID);
	public static final RegistryObject<SoundEvent> LOLI_SUCCRSS = REGISTRY.register("loli_succrss", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("loli_pickaxe", "loli_succrss")));
	public static final RegistryObject<SoundEvent> LOLIRECORD = REGISTRY.register("lolirecord", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("loli_pickaxe", "lolirecord")));
}
